#ifndef __AVL__H__
#define __AVL__H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include<stdbool.h>

/* Définition structure AVL*/
typedef struct Avl{
	int value;
	int equilibre;
	struct Avl* fg;
	struct Avl* fd;
}Avl, *pAvl;

/* Prototype des fonctions */
pAvl creerArbre(int value);
int max(int a, int b);
int min(int a, int b);
pAvl RotationGauche(pAvl tr);
pAvl RotationDroite(pAvl tr);
pAvl doubleRotationGauche(pAvl tr);
pAvl doubleRotationDroite(pAvl tr);
pAvl equilibrerAvl(pAvl tr);
int compare(int a, int b);
void inserer(pAvl* tr, int x);
void clear_avl(pAvl tr);
void print_avl_prefix(pAvl tr);


#endif

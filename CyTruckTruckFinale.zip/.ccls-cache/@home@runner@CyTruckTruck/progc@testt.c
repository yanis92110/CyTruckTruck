#include "header.h"

typedef struct Aville{
    Ville ville;
    struct Aville* fg;
    struct Aville* fd;
    int eq;
}Aville;

typedef struct Ville2{
    char nom[23];
    int compteur;
}Ville2;


void dix_plus_visitees(Aville* a, int* decompte){

    if (a != NULL){
        if (existeFilsDroit()){
            dix_plus_visitees(a->fd,decompte);
        }
    }
}

int main(){
    return 0;

}
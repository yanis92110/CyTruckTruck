#include"avl.h"

int main(void){
	pAvl tr = creerArbre(3);
	inserer(&tr, 4);
	inserer(&tr, 1);
	inserer(&tr, 14);
	print_avl_prefix(tr);
	inserer(&tr, 17);
	tr = equilibrerAvl(tr);
	print_avl_prefix(tr);
	clear_avl(tr);
	return 0;
}

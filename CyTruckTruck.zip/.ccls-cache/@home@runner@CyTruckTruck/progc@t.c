#include "header.h"


ListeVille* creerListe(){
  ListeVille* pville=malloc(sizeof(ListeVille);
  pville->count=0;
  pville->id=0;
  pville->etape=0;
  pville->villedeb=NULL;
  pville->villefin=["test"];
  pville->suivant=NULL;
  return pville;
}

int main(int argc, char* argv[]){
  //on va dire que ca prend en param que les colones: IDtrajet, etape, nom ville;
  //1. mettre dans liste chainée on met quoi ? 
  //
  FILE *data = fopen("trajet.txt", "rwx");
   if (data == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
        return 1;
  }
  
  ListeVille* pville=creerListe();
  char ligne[35];
  while(fgets(ligne, sizeof(ligne), data)!=NULL){
    
  }
  
  
}
#include"avl.h"

pAvl creerArbre(int value){
	pAvl tr = (pAvl)malloc(sizeof(Avl));
	
	if(tr == NULL){
		fprintf(stderr,"Erreur d'allocation mémoire \n");
		exit(EXIT_FAILURE);
	}
	
	tr->value = value;
	tr->equilibre = 0;
	tr->fg = tr->fd = NULL;
	
	return tr;
}

int max(int a, int b) {
    return a > b ? a : b;
}

int min(int a, int b) {
    return a <= b ? a : b;
}

pAvl rotationGauche(pAvl tr){
	pAvl pivot;
	int eqA,eqB;
	
	pivot = tr->fd;
	tr->fd = pivot->fg;
	pivot->fg = tr;
	
	eqA = tr->equilibre;
	eqB = pivot->equilibre;
	
	tr->equilibre = eqA-max(eqB,0)-1;
	pivot->equilibre = min(min(eqA-2,eqA+eqB-2),eqB-1);
	
	tr = pivot;
	
	return tr;
}

pAvl rotationDroite(pAvl tr){
	pAvl pivot;
	int eqA,eqB;
	
	pivot = tr->fg;
	tr->fg = pivot->fd;
	pivot->fd = tr;
	
	eqA = tr->equilibre;
	eqB = pivot->equilibre;
	
	tr->equilibre=eqA-min(eqB,0)+1;
	pivot->equilibre = max(max(eqA+2,eqA+eqB+2),eqB+1);
	
	tr=pivot;
	
	return tr;
}

pAvl doubleRotationGauche(pAvl tr){
	pAvl pivot;
	tr->fg = rotationDroite(tr->fg);
	
	return rotationGauche(tr);
}

pAvl doubleRotationDroite(pAvl tr){
	pAvl pivot;
	tr->fg = rotationGauche(tr->fg);
	
	return rotationDroite(tr);
}

pAvl equilibrerAvl(pAvl tr){
	if(tr->equilibre >= 2){
		if(tr->fd->equilibre <= 0)
			return rotationGauche(tr);
		
		else
			return doubleRotationGauche(tr);
	}
	else if(tr->equilibre <= 2){
		if(tr->fg->equilibre <= 0)
			return rotationDroite(tr);
		
		else
			return doubleRotationDroite(tr);
		
	}
	return tr;
}

int compare(int a, int b)
{
	if (a < b)
		return -1;
	else if (a > b)
		return 1;
	else if (a == b)
		return 0;
}

void inserer(Avl** tr, int x)
{
    if (*tr == NULL)
    {
        // Si l'arbre est vide, créer un nouveau nœud
        pAvl ts = malloc(sizeof(Avl));
        if (ts == NULL)
        {
            fprintf(stderr, "Erreur allocation mémoire.\n");
            exit(EXIT_FAILURE);
        }

        ts->value = x;
        ts->fg = ts->fd = NULL;
        *tr = ts;
    }
    else
    {
        int cmp = compare(x, (*tr)->value);
        if (cmp == 0)
        {
            printf("Ce nombre est déjà dans l'abr\n");
        }
        else if (cmp < 0)
        {
            inserer(&((*tr)->fg), x);
        }
        else
        {
            inserer(&((*tr)->fd), x);
        }
    }
}

void clear_avl(pAvl tr)
{
	if (tr == NULL)
		return;
		
	//Aide pour le développeur
	printf("Suppression de %d\n", tr->value);
	
	
	clear_avl(tr->fg);
	clear_avl(tr->fd);
	
	free(tr);
	
}

void print_avl_prefix(pAvl tr)
{
	if(tr == NULL)
		return;
	
	else
		printf("[%d]\n", tr->value);
	
	if(tr->fg != NULL)
		print_avl_prefix(tr->fg);
	
	if(tr->fd != NULL)
		print_avl_prefix(tr->fd);

}
	

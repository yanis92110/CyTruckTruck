#include "header.h"

typedef struct Ville{
    int compteur;
    char nom[23];
    struct Ville* next;
}Ville;

typedef struct Trajet{
    int ID;
    int IDE;
    Ville VD;
    Ville VA;
    struct Trajet* next;
}Trajet;


Trajet* creer_listeT(){
    Trajet* tra = malloc(sizeof(Trajet));
    tra->next = NULL;
    return tra;
}

Ville* creer_listeV(){
    Ville* vil = malloc(sizeof(Trajet));
    vil->next = NULL;
    return vil;
}
Ville* creer_ville(char nom[23]){
  Ville* v=malloc(sizeof(Ville));
  v->compteur=1;
  strcpy(v->nom,nom);
  v->next=NULL;
  return v;
}


void ajouter_trajet(Trajet* tete,Trajet actuel){
    Trajet* temp = tete;
    tete = &actuel;
    actuel.next = temp;    
}

void ajouter_ville(Ville* tete, Ville ville){
  //Fonction qui prend en parametre une liste chainée de villes et une ville, qui cherche si la ville actuelle existe dans la liste chainée, si oui incrémente son compteur et si non ajoute la ville en fin de liste
    if (tete == NULL){
        tete = &ville;
        return;
    }else{
        Ville* temp = tete;
        while(temp->next!=NULL){
            if(strcmp(temp->nom,ville.nom) == 0){
                temp->compteur ++;
                return;
            }
            else {
                temp = temp->next;
            }
        }
        temp->next = &ville;
        ville.compteur=1;
        return;
    }
}


Trajet* comparer_trajet (Trajet* tra, Ville* vil,Trajet actuel){
  //Fonction qui prend en parametre un pointeur sur un Trajet et un trajet, qui ajoute trajet a la pile en renvoyant la tete de la pile
    Trajet* temp = tra;
    int va=0,vd=0;
    while (temp->next != NULL){
         if (actuel.ID == temp->ID){
             if (actuel.IDE +1 == temp->IDE){
                 va=1;
             } else if (actuel.IDE -1 == temp->IDE){
                 vd=1;
             }
         }
        temp = temp->next;
    }
    if (va == 0){
        ajouter_ville(vil,actuel.VA);
        //incrémenter le compteur de la ville d'arrivée dans l'AVL et réorganiser l'AVL
    }
    if (vd == 0){
        ajouter_ville(vil,actuel.VD);
        //incrémenter le compteur de la ville de départ dans l'AVL et réorganiser l'AVL
    }
    ajouter_trajet(tra,actuel);
    return tra;
}


int main(){
    Trajet* tra = creer_listeT();
    Ville* vil = creer_listeV();
    return 0;
}
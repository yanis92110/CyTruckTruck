#include "header.h"

typedef struct Ville{
    int compteur;
    char nom[23];
    struct Ville* next;
}Ville;

typedef struct Trajet{
    int ID;
    int IDE;
    Ville* VD;
    Ville* VA;
    struct Trajet* next;
}Trajet;

Ville* creerVille(){
    Ville* v=malloc(sizeof(Ville));
    v->compteur=0;
    v->next=NULL;
    strcpy(v->nom,"");
    return v;
}

Trajet* creerTrajet(){
    Trajet* t=malloc(sizeof(Trajet));
    t->ID=0;
    t->IDE=0;
    t->next=NULL;
    t->VA=creerVille();
    t->VD=creerVille();
    return t;
}

void ajouter_trajet(Trajet* tete,Trajet actuel){
    Trajet* temp = tete;
    tete = &actuel;
    actuel.next = temp;    
}


void lectureFichier(Trajet* nouveau)
//Fonction qui créer une liste chainée de Trajets avec les 4 premières colonnes de data.csv
{

    FILE* fichier = fopen("test.txt","r");
    char mot[23];
    char current = 'v';
    int nbComma = 0;
    int i = 0;


    if (fichier != NULL)
    {
        rewind(fichier);
        do 
        {
            while(current!=';')
            {
                current = getc(fichier);
                mot[i] = current;
                i ++;

            }
            nbComma ++;
            switch(nbComma){
                case 1:
                    //alors on a affaire au ID

                    nouveau->ID=atoi(mot);
                    break;
                case 2:
                    //alors on a affaire au etape
                    nouveau->IDE=atoi(mot);
                    break;
                case 3:
                    //alors on a affaire au ville depart
                    strcpy(nouveau->VD->nom,mot);
                    break;
                case 4:
                    //alors on a affaire ville fin
                    strcpy(nouveau->VA->nom,mot);
                    break;
                default:
                    nbComma=0;
                    break;


            }

        }while(mot!=NULL);

        fclose(fichier);
    }
    else
    {
        printf("Erreur lors de l'ouverture du fichier !\n");
        exit(11);
    }

}
int main(){
    Trajet* tra=malloc(sizeof(Trajet));
    lectureFichier(tra);
    ajouter_trajet(tra,)

}
#!/bin/bash

data="data.csv"
temp="temp"
fichier="$temp/fichier.txt"
touch "$fichier"
cut -d ';' -f 1,2,3,4 "$data" > $fichier
